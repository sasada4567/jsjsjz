# HTTP Browser

HTTP Browser method developed by unknown developer

# Usage

node index.js "https://google.com/" --humanization true --mode tlsfl --precheck false --proxy proxies.txt --time 3000 --pool 20 --uptime 15000 --workers 50 --proxylen 21000 --delay 10000 --junk true --pipe 500

Method leaked because its very old and broken in some parts.
